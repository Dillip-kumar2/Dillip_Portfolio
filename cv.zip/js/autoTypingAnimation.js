setTimeout(function() {
    $('.about-info-inner').typed({
      strings: [
        "<span>Hi, I am Dillip Kumar</span> Currently I am living in Noida Sector 62. <br> <br>  I recently completed my Post Graduation MCA from Galgotias University, Greater Noida, in 2024. Now, <br> <br> I'm seeking for job the opportunity as per my skills and achievments. <br> <br> I have skills in web designing skills with html, css, javascript and React.js, Node.js, MongoDB.<br> <br>  I make many projects related to my skills while learing time which make me more experience in this fields."
      ],
      typeSpeed: 7,
      contentType: 'html'
    });
  }, 100);
